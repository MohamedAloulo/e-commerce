const btn = document.getElementById("btn");
const navLinks = document.getElementById("nav")
btn.addEventListener('click', () => {
    if(navLinks.style.display=="none"){
        navLinks.style.display="block";
    }else{
        navLinks.style.display="none";
    }
});
window.onload = ()=>{
     navLinks.style.display="none"
}